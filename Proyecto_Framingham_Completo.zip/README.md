# Proyecto Framingham - Regresión Logística

## Objetivo
Predecir el riesgo de enfermedad coronaria a 10 años utilizando regresión logística.

## Contenido
- Preprocesamiento de datos
- Exploración de variables
- Modelo de regresión logística
- Variables significativas
- Matriz de confusión
- Curva ROC
- Modelo simplificado
- Exportación de resultados

## Estructura
DATASET/
SCRIPT_R/
DOCUMENTO_SOPORTE/
resultados/
