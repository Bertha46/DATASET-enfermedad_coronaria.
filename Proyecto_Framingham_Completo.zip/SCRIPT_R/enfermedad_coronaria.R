
# ACTIVIDAD FRAMINGHAM
library(tidyverse)
library(caret)
library(pROC)

datos <- read.csv("enfermedad_coronaria.csv")

str(datos)
summary(datos)

colSums(is.na(datos))
datos <- na.omit(datos)

datos$Riesgo_10Anios <- as.factor(datos$Riesgo_10Anios)

set.seed(123)
idx <- createDataPartition(datos$Riesgo_10Anios,p=.8,list=FALSE)
train <- datos[idx,]
test <- datos[-idx,]

modelo <- glm(Riesgo_10Anios~.,data=train,family=binomial())
summary(modelo)

prob <- predict(modelo,newdata=test,type="response")
pred <- as.factor(ifelse(prob>.5,1,0))

cm <- confusionMatrix(pred,test$Riesgo_10Anios)
print(cm)

roc_obj <- roc(test$Riesgo_10Anios,prob)
plot(roc_obj)

modelo_reducido <- glm(Riesgo_10Anios~Edad+SysBP,data=train,family=binomial())
summary(modelo_reducido)
